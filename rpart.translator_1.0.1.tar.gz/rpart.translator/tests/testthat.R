library(testthat)
library(rpart.translator)

test_check("rpart.translator")
